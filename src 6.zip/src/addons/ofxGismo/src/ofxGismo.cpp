#include "ofxGismo.h"

using namespace std;

//Imlementations of C Functions

float initAgent(ag_t *tmp, float fval){
    
//        tmp->active = true;
    tmp->active = false;
//    tmp->posi.x = 0.5f;
//    tmp->posi.y = 0.5f;
    tmp->posi.x = logistic(fval);
    tmp->posi.y = logistic(tmp->posi.x);
    tmp->size = 0.0137f;
    tmp->view = 0.1f;
    tmp->mov = 0.01f;
    
    return tmp->posi.y; //Return final fval to next randomize in initAgent[s]()
    
}

float initAgentActive(ag_t *tmp,  float fval){
    
    float fval2 = initAgent(tmp, fval);
    tmp->active = true;
    return fval2;
    
}


void initAgents(ag_t *ags){ //Init all agents with default paramas
    
    printf("initAgents\n");
    float position_ramdom_seed = 0.5;
    for (int i=0; i<AG_MAX; i++){
        
        position_ramdom_seed = initAgent(ags,position_ramdom_seed); //set the agent buf
        cout << position_ramdom_seed << endl;
        ags++; //Increment the index
        
    }
    
    
    
}


void initPutBuff(put_buf_t *put_buf){
    
    put_buf->count = 0;
    ag_t *ags = put_buf->buf;
    
    for(int i=0; i<AG_BUF_MAX; i++){
        
        initAgent(ags);
        ags++;
        
    }
    
}



void addAgentToBuff(ag_t ag, put_buf_t *put_buf){ //Put agent to buff
    
    put_buf->buf[put_buf->count] = ag;
    put_buf->count += 1;
    
}


void agBuffReset(agent_buf_t *agents){
    
    for(int i=0; i<agents->count;i++){
        
        agents->buf[i].active = false;
        
    }
    agents->count = 0;
    
}




//Interaction Tool Kits
float distance(posi_t p1, posi_t p2){
    
    posi_t tmp;
    // calc differences
    tmp.x = p2.x - p1.x;
    tmp.y = p2.y = p2.y;
    
    tmp.x = tmp.x*tmp.x;
    tmp.y = tmp.y*tmp.y;
    
    //	pythagoras theorem
    return (float)( sqrt(tmp.x+tmp.y) );
    
    
}


int seekNearest(int ag_id, agent_buf_t *agbuf){
    
    ag_t *forcus = &agbuf->buf[ag_id];
    ag_t *target;
    int nearest_id = -1;
    float nearest_val = 999.0f;
    float val = 0.0f;
    for(int i=0; i<agbuf->count;i++){
        target = &agbuf->buf[i];
        if (target->active == false || ag_id == i){ //Ignore dead or void agent or myself
            
            continue;
            
        }
        val = distance(forcus->posi, target->posi);
        
        if(val < nearest_val){ //If find tmpolary longest
            
            nearest_id = i; //store the id
            nearest_val = val; //update the lon
        }
        
    } // end of for
    
    return nearest_id;
    
    
}


bool isViewRange(ag_t *ag, float distance){
    
    if(ag->view > distance) return true;
    else if (ag->view <= distance) return false;
    
}


void move(ag_t *ag, posi_t *posi){
    
    GismoManager& gismo = GismoManager::getInstance();
    
    //decision X
    if ( isLarge(ag->posi.x, posi->x) ) ag->posi.x = ag->posi.x - (gismo.random()*ag->mov);
    else ag->posi.x = ag->posi.x + ( gismo.random() * ag->mov );
    //decision y
    if ( isLarge(ag->posi.y, posi->y) ) ag->posi.y = ag->posi.y - (gismo.random()*ag->mov);
    else ag->posi.y = ag->posi.y + ( gismo.random() *ag->mov);
    
}


void randomMove(ag_t *ag){

    GismoManager& gismo = GismoManager::getInstance();

    //for X
    float fval = gismo.random();
    //invert sign randomly
    if( fmod(fval, 2.0) == 0.0 )fval *= 1;
    else fval *= -1;
    //Set the next X
    ag->posi.x = ag->posi.x + (ag->mov*fval);

    //for Y
    fval = gismo.random();
    //invert sign randomly
    if( fmod(fval, 2.0) == 0.0 )fval *= 1;
    else fval *= -1;
    //Set the next X
    ag->posi.y = ag->posi.y + (ag->mov*fval);

    
}


void interactWith(ag_t *focus , ag_t *target){
    
    float dist = distance(focus->posi, target->posi);
    if (isViewRange(focus, dist)){
        
        if( isLarge(focus->size, target->size) ){
//            cout << "chase" << endl;
            move(focus, &target->posi);
        } else {
//            cout << "run" << endl;
            posi_t tmp = target->posi; //set invert position for running
            tmp.x = tmp.x*(-1);
            tmp.y = tmp.y*(-1);
            move(focus, &tmp);
        }
        
    }else{
        
        randomMove(focus);
        
    }
    
}


void makeInteracts(agent_buf_t *agents){

    int nearest = -1;
    
    if (agents->count==1){
        
        randomMove(&agents->buf[0]);
        return; //when an agent only, do randomwalk.
        
    }
    
    for(int i=0; i<agents->count;i++){
        
        //DUMMYMOVE
        randomMove(&agents->buf[i]);
        continue;
        
        nearest = seekNearest(i, agents);
        if(nearest != -1) interactWith(&agents->buf[i], &agents->buf[nearest]);
        
    }
    
}


float logistic(float fval){
    
    float tmp = 1.0f-fval;
    tmp = (tmp*fval)*3; //3 is constant
    return tmp;
    
}



//Definication of GismoManager :::::::::::

GismoManager::GismoManager() //Constructor
{

    initAgents(agents.buf);
    agents.count = 0;
    put_buf_t add;
    initPutBuff(&add);
    
}
    
ag_t* GismoManager::getAgents()
{
    
    return agents.buf;
    
}

void GismoManager::addAgent(ag_t tmp){
    
    addAgentToBuff(tmp, &add);
    
}

void GismoManager::addSync(){
    
    
    for(int i=0; i<add.count;i++){
        
        agents.buf[agents.count]=add.buf[i];
        agents.count++;
        
    }
    add.count = 0; //reset add_buf count
    
}

float GismoManager::random(){
    
    float fval = seed[random_count];
    random_count+=1;
    if(random_count>=SEED_MAX){
        
        random_count=0;
        
    }
    return fval;
    
}




