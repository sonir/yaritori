
// How to Use from your src
//      GismoManager& gismo = GismoManager::getInstance();
//      cout << gismo.foo << endl;
//      gismo.foo = 139;



#pragma once

// PARAMS SET MACROS
#define AG_MAX 5000



///

#include <iostream>
#include <math.h>
#include "agTypes.h"


//Function Prototypes
//Inits
void initAgent(ag_t *ags);
void initAgentActive(ag_t *ags);
void initAgents(ag_t *ags);
void initPutBuff(put_buf_t *put_buf);
//AgentOperation
void addAgentToBuff(ag_t ag, put_buf_t put_buf);
//InteractionTool
float distance(posi_t p1, posi_t p2);


//Class for Data management

class GismoManager{
    
    public:
        //Kill methods related with duplication of instance
        GismoManager(const GismoManager&) = delete;
        GismoManager& operator=(const GismoManager&) = delete;
        GismoManager(GismoManager&&) = delete;
        GismoManager& operator=(GismoManager&&) = delete;
    
        static GismoManager& getInstance(){
            static GismoManager instance; //Invoke privated constructor
            return instance;
        }
    
        const char* getString(){
            return "Hello world!";		//to invoke, write " Singleton::getInstance().getString(); " 
        }
    
        //Variables
        int count = 0;
        ag_t agents[AG_MAX];
        put_buf_t add;

        //Methods
        ag_t* getAgents();
        void addAgent(ag_t tmp);
        void addSync(); //Sync actual agent array and add_buffer


    
    private:
        GismoManager();
        ~GismoManager() = default;
    
    
    
};


