#include "ofxGismo.h"

using namespace std;

//Imlementations of C Functions

void initAgent(ag_t *tmp){
    
    tmp->active = false;
    tmp->posi.x = 0.5f;
    tmp->posi.y = 0.5f;
    tmp->size = 0.0137f;
    tmp->view = 0.137f;
    
}

void initAgentActive(ag_t *tmp){
    
    initAgent(tmp);
    tmp->active = true;
    
}


void initAgents(ag_t *ags){ //Init all agents with default paramas
    
    printf("initAgents\n");
    
    for (int i=0; i<AG_MAX; i++){
        
        initAgent(ags); //set the agent buf
        ags++; //Increment the index
        
    }
    
    
    
}


void initPutBuff(put_buf_t *put_buf){
    
    put_buf->count = 0;
    ag_t *ags = put_buf->buf;
    
    for(int i=0; i<AG_BUF_MAX; i++){
        
        initAgent(ags);
        ags++;
        
    }
    
}



void addAgentToBuff(ag_t ag, put_buf_t *put_buf){ //Put agent to buff
    
    put_buf->buf[put_buf->count] = ag;
    put_buf->count += 1;
    
}



//Interaction Tool Kits
float distance(posi_t p1, posi_t p2){
    
    posi_t tmp;
    // calc differences
    tmp.x = p2.x - p1.x;
    tmp.y = p2.y = p2.y;
    
    tmp.x = tmp.x*tmp.x;
    tmp.y = tmp.y*tmp.y;
    
    //	pythagoras theorem
    return (float)( sqrt(tmp.x+tmp.y) );
    
    
}


int seekNearest(int ag_id, agent_buf_t *agbuf){
    
    ag_t *forcus = &agbuf->buf[ag_id];
    ag_t *target;
    int nearest_id = -1;
    float nearest_val = 999.0f;
    float val = 0.0f;
    for(int i=0; i<agbuf->count;i++){
        target = &agbuf->buf[i];
        if (target->active == false || ag_id == i){ //Ignore dead or void agent or myself
            
            continue;
            
        }
        val = distance(forcus->posi, target->posi);
        
        if(val < nearest_val){ //If find tmpolary longest
            
            nearest_id = i; //store the id
            nearest_val = val; //update the lon
        }
        
    } // end of for
    
    return nearest_id;
    
    
}


bool isViewRange(ag_t *ag, float distance){
    
    if(ag->view<distance) return true;
    else if (ag->view>=distance) return false;
    
}


//Definication of GismoManager :::::::::::

GismoManager::GismoManager() //Constructor
{

    initAgents(agents.buf);
    agents.count = 0;
    put_buf_t add;
    initPutBuff(&add);
    
}
    
ag_t* GismoManager::getAgents()
{
    
    return agents.buf;
    
}

void GismoManager::addAgent(ag_t tmp){
    
    addAgentToBuff(tmp, &add);
    
}

void GismoManager::addSync(){
    
    
    for(int i=0; i<add.count;i++){
        
        agents.buf[agents.count]=add.buf[i];
        agents.count++;
        
    }
    add.count = 0; //reset add_buf count
    
}

float GismoManager::random(){
    
    float fval = seed[random_count];
    random_count+=1;
    if(random_count>=SEED_MAX){
        
        random_count=0;
        
    }
    return fval;
    
}



