#include "ofxGismo.h"

GismoManager *GismoManager::g_pInstance = NULL; //Init unique instance with NULL



void GismoManager::Create()
{
    
    
    if(!g_pInstance)
    {
        
        g_pInstance = new GismoManager;
        
    }
    
    
    
}



void GismoManager::Terminate()
{
    
    delete g_pInstance;
    g_pInstance = NULL;
    
}
