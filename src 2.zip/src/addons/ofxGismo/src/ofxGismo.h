
// How to Use from your src
//      GismoManager& gismo = GismoManager::getInstance();
//      cout << gismo.foo << endl;
//      gismo.foo = 139;



#pragma once

// PARAMS SET MACROS
#define AG_MAX 5000



///

#include <stdio.h>



//Define Structs
typedef struct posi_t {
    
    float x;
    float y;
    
} posi_t;


typedef struct ag_t {
    
    bool active;
    posi_t posi;
    float size;
    float view;
    
    
} ag_t;



//Function Prototypes

void initAgents(ag_t *ags);

//Class for Data management

class GismoManager{
    
    public:
        //Kill methods related with duplication of instance
        GismoManager(const GismoManager&) = delete;
        GismoManager& operator=(const GismoManager&) = delete;
        GismoManager(GismoManager&&) = delete;
        GismoManager& operator=(GismoManager&&) = delete;
    
        static GismoManager& getInstance(){
            static GismoManager instance; //Invoke privated constructor
            return instance;
        }
    
        const char* getString(){
            return "Hello world!";		//to invoke, write " Singleton::getInstance().getString(); " 
        }
    
        //Variables
        int count = 0;
        //Methods
        ag_t* getAgents();
        ag_t agents[AG_MAX];

    
    private:
        GismoManager();
        ~GismoManager() = default;
    
    
    
};


