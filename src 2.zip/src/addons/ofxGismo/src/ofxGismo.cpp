#include "ofxGismo.h"


//Imlementations of C Functions

void initAgents(ag_t *ags){ //Init all agents with default paramas
    
    printf("initAgents\n");
    ag_t *tmp;
    
    for (int i=0; i<AG_MAX; i++){
        
        tmp = ags;
        tmp->active = false;
        tmp->posi.x = 0.5f;
        tmp->posi.y = 0.5f;
        tmp->size = 0.0137f;
        tmp->view = 0.137f;
        ags++; //Increment the index
        
    }
    
    
    
}





//Definication of GismoManager :::::::::::

GismoManager::GismoManager() //Constructor
{

    initAgents(agents);
    
}
    
ag_t* GismoManager::getAgents()
{
    
    return agents;
    
}

